var username='arvind'
var city = 'chennai';
var email='onebrownre@gmail.com'
var phone='xxxxxxxxxx'+

          
var details = username+' is from '+city; 
console.log(details);
console.log(name,'is from',city)
console.log(msg);
