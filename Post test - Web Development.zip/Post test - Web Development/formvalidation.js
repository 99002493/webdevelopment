function validation(){
    if(document.getElementById("firstname").value==""){
     alert("Enter your First Name");
     document.Formvalidation.username.focus();
     }
    else if(document.getElementById("lastname").value==""){
         alert("Enter your Last Name");
         document.Formvalidation.username.focus();
         }

    else if(document.getElementById("pswd").value==""){
     alert("Enter Password");
     document.registerform.password.focus();
     }
     else if(document.getElementById("email").value==""){
        alert("Enter Email");
        document.registerform.Email.focus();
        }
        else if(document.getElementById("phno").value==""){
            alert("Enter Password");
            document.registerform.phonenumber.focus();
            }
    else{
     validateuser();
    // alert("You are successfully registered ");
     
     }
    }
    function validateuser(){
    var uns=["Arvind","Kumar","DR","XYZ"];
    var f=0;
    var uname1=document.getElementById("firstname").value;
    // uname=prompt('Enter username');
    for(let i=0;i<uns.length;i++){
    if(uname1==uns[i])
     {
     
     f=1;
    break;
     }
     
     }
    if(f==1){
     alert("username already exists");
     }
    else{
     
        document.getElementById("mydiv").innerHTML='Welcome, you are successfully registered!';
     }
    }